import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:trying_database_php/real_app/pages/costume_page.dart';
import 'package:trying_database_php/real_app/help/home_page.dart';
import 'package:trying_database_php/real_app/help/home_page2.dart';
import 'package:trying_database_php/real_app/widgets/date_picker.dart';
import 'package:trying_database_php/real_app/pages/form_page.dart';
import 'package:trying_database_php/real_app/pages/reclamation_form.dart';


void main() {
  runApp(GetMaterialApp(
    debugShowCheckedModeBanner: false,
    home:  ReclamationForm(),
    )
  );
}
