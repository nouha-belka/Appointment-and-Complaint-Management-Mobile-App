import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:trying_database_php/real_app/help/constants.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:trying_database_php/real_app/pages/form_page.dart';

import 'dart:convert';

import '../help/home_page2.dart';
class CostumePage extends StatefulWidget {
  const CostumePage({Key? key}) : super(key: key);

  @override
  _CostumePageState createState() => _CostumePageState();
}

class _CostumePageState extends State<CostumePage> {
  late TextEditingController  codectrl, passctrl;
  bool processing = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    codectrl =  TextEditingController();
    passctrl =  TextEditingController();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: mainColor,
      body: SingleChildScrollView(
        child: SafeArea(
          child: Column(
            children: [
              Container(
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      containerShadow
                    ],
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(60),
                      bottomRight: Radius.circular(60),
                    ),
                  ),
                padding: const EdgeInsets.all(20),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      SizedBox(height: 80 ,),
                      TextField(
                          controller: codectrl,
                        decoration: textInputDeco.copyWith(hintText: 'Code client')
                      ),
                      SizedBox(height: 40 ,),
                      TextField(
                          controller: passctrl,
                          decoration: textInputDeco.copyWith(hintText: 'Mot de passe')
                      ),
                      SizedBox(height: 50 ,),
                      ElevatedButton(
                        onPressed: (){
                          signInUser();
                        },
                        style: ButtonStyle(
                          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                              RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0),)
                          ),
                            backgroundColor: MaterialStateProperty.all<Color>(mainColor),
                        ),
                        child:  Padding(
                          padding:  EdgeInsets.fromLTRB(30, 13, 30, 13),
                          child: processing == false ? Text(
                              "Se connecter",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                            ),
                          ) : spinkit,
                        ),
                      ),
                      SizedBox(height: 30 ,),
                      InkWell(
                        onTap: () => Get.to(() => HomePage2()),
                        child: const Text(
                            "Demande sans compte",
                          style: TextStyle(color: Color.fromRGBO(69, 135, 150, 1),fontSize: 17,fontWeight: FontWeight.bold),
                        ),
                      ),
                      SizedBox(height: 30 ,),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(55, 25, 30, 0),
                child: Image.asset("assets/Logo.png"),
              ),
            ],
          ),
        ),
      ),
    );
  }
  void signInUser() async{
    setState(() {
      processing = true;
    });
    var url = "http://192.168.56.1/php_project/web-flutter/seConnecter.php";
    var data = {
      "code" : codectrl.text,
      "pass" : passctrl.text,
    };
    var res = await http.post(Uri.parse(url),body: data);
    if(jsonDecode(res.body) == "true"){
      Fluttertoast.showToast(msg: "account exists",toastLength: Toast.LENGTH_SHORT);
      Get.to(() => FormPage());

    }else{
      Fluttertoast.showToast(msg: "account doesn't exist, Please sign up ",toastLength: Toast.LENGTH_SHORT);
    }
    setState(() {
      processing = false;
    });
  }
}
