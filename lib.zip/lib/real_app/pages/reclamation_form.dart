import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:trying_database_php/real_app/help/constants.dart';
import 'package:trying_database_php/real_app/widgets/circle.dart';
import 'package:trying_database_php/real_app/widgets/costume_tile.dart';
import 'package:trying_database_php/real_app/widgets/menu.dart';

class ReclamationForm extends StatefulWidget {
  const ReclamationForm({Key? key}) : super(key: key);

  @override
  _ReclamationFormState createState() => _ReclamationFormState();
}

class _ReclamationFormState extends State<ReclamationForm> {
  CarouselController buttonCarouselController = CarouselController();
  String trying = "";
  bool round1 = false;
  bool round2 = false;
  bool round3 = false;
  double animationWidth = 0;
  double animationHeight = 20;
  Color animetionColor = Colors.black26;
  bool listIsChoosen = false;
  void trying_f(String tileContent ){
    setState(() {
      listIsChoosen = false;
      trying = "${tileContent}";
      print("${trying}");
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(248, 248, 248, 1),
      drawer: Menu(),
      appBar: AppBar(
        backgroundColor: mainColor,
        title: Text(
          "Reclamation",
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              padding: EdgeInsets.fromLTRB(20, 0, 20, 0),
              decoration: ContainerDeco,
              alignment: Alignment.center,
              height: 150,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 5,
                    color:  Colors.black26,
                    width: 60,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        AnimatedContainer(
                          width: animationWidth,
                          height: 5,
                          color: mainColor ,
                          duration: Duration(milliseconds: 250),
                        ),
                      ],
                    )
                  ),

                  //Container(height: 5,color: round1 ? mainColor : Colors.black26,width: 60,),
                  Circle(circleIcon: Icons.list_rounded,isFiniished: round1,),
                  Container(height: 5,color: round2 ? mainColor : Colors.black26,width: 60,),
                  Circle(circleIcon: Icons.check_circle,isFiniished: round2,),
                  Container(height: 5,color: Colors.black26,width: 60,),
                ],
              ),
            ),
            CarouselSlider(
              options: CarouselOptions(
                height: 330,
                enableInfiniteScroll: false,
                viewportFraction : 1,
                autoPlay: false,
                onPageChanged: (index,reason){
                  if(index == 0){
                    setState(() {
                      round1 = false;
                      animationWidth = 0;
                    });
                  }else{
                    if(index == 1){
                      setState(() {
                        animationWidth = 60;
                      });
                      Future.delayed(Duration(milliseconds: 200), () {
                        setState(() {
                          round1 = true;
                        });
                      });
                    }
                  }
                }
              ),
              carouselController: buttonCarouselController,
              items: [1,2].map((i) {
                return Builder(
                  builder: (BuildContext context) {
                    if(i == 1){
                      return Padding(
                        padding: const EdgeInsets.fromLTRB(0, 0, 0, 5),
                        child: Container(
                          margin: EdgeInsets.symmetric(horizontal: 5.0),
                          decoration: ContainerDeco,
                          height: 330,
                          child: Padding(
                            padding: const EdgeInsets.all(20),
                            child: ListView(
                              children: [
                                CostumeTile(content: "- Surfacturation", onTapFunstion: trying_f,isChoosen: listIsChoosen),
                                SizedBox(height: 10 ,),
                                CostumeTile(content: "- j'ai pas reçu une facture", onTapFunstion: trying_f,isChoosen: listIsChoosen),
                                SizedBox(height: 10 ,),
                                CostumeTile(content: "- je n'est pas ete relevé ", onTapFunstion: trying_f,isChoosen: listIsChoosen),
                                SizedBox(height: 10 ,),
                                CostumeTile(content: "- une fuite au niveaux extérieur", onTapFunstion: trying_f,isChoosen: listIsChoosen),
                                SizedBox(height: 10 ,),
                                CostumeTile(content: "- une fuite au niveaux intérieur", onTapFunstion: trying_f,isChoosen: listIsChoosen),
                                SizedBox(height: 10 ,),
                                CostumeTile(content: "- je suis victime de fraude", onTapFunstion: trying_f,isChoosen: listIsChoosen),
                                SizedBox(height: 10 ,),
                                CostumeTile(content: "- j'ai payé ma facture mais vous m'avez coupé la ligne", onTapFunstion: trying_f,isChoosen: listIsChoosen),
                              ],
                            ),
                          ),
                        ),
                      );
                    }else{
                      if(i == 2 ){
                        return Padding(
                          padding: const EdgeInsets.fromLTRB(0, 0, 0, 5),
                          child: Container(
                            margin: EdgeInsets.symmetric(horizontal: 5.0),
                            decoration: ContainerDeco,
                            height: 300,
                          ),
                        );
                      }
                      return Text("hello");
                    }
                  },
                );
              }).toList(),
            ),
            ElevatedButton(
                style: ButtonStyle(
                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(borderRadius: BorderRadius.circular(11.0),)
                  ),
                  backgroundColor: MaterialStateProperty.all<Color>(mainColor),
                ),
                onPressed: ()async{

                  buttonCarouselController.nextPage(
                      duration: Duration(milliseconds: 250), curve: Curves.linear);

                },
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(60, 10, 60, 10),
                  child: Text(
                    "Suivant",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                    ),
                  ),
                ))
          ],
        ),
      ),
    );
  }
}
