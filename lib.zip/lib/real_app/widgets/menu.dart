import 'package:flutter/material.dart';
import 'package:trying_database_php/real_app/help/constants.dart';

class Menu extends StatelessWidget {
  const Menu({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: [
          UserAccountsDrawerHeader(
            accountName: Text(
                '123456789',
              style: TextStyle(fontSize: 17),
            ),
            accountEmail: Text(
                'Nouha Belkacemi',
              style: TextStyle(fontSize: 15),
            ),
            decoration: BoxDecoration(

              color: Colors.white,
              image: DecorationImage(
                alignment: Alignment.bottomCenter,
                  scale: 1.5,
                  image:AssetImage("assets/Vector (1).png"),
              ),
            ),
          ),
          ListTile(
            leading: Icon(
              Icons.menu,
              color: greyColor,
            ),
            title: Text(
              'Accueil',
              style: menuTextStyle,
            ),
            onTap: () => null,
          ),
          Divider(
            color: mainColor,
            thickness: 2,
            height: 20,
            indent: 40,
            endIndent: 20,
          ),
          ListTile(
            leading: Icon(
                Icons.folder,
              color: greyColor,
            ),
            title: Text(
                'Mes réclamations',
              style: menuTextStyle,
            ),
            onTap: () => null,
          ),
          ListTile(
            leading: Icon(
              Icons.folder,
              color: greyColor,
            ),
            title: Text(
              'Mes demandes',
              style: menuTextStyle,
            ),
            onTap: () => null,
          ),


        ],
      ),
    );
  }
}
