import 'package:flutter/material.dart';
import 'package:trying_database_php/real_app/help/constants.dart';

class FormContainer extends StatelessWidget {
  String phrase,buttonText;
  IconData containerIcon ;
  FormContainer({required this.phrase, required this.buttonText,required this.containerIcon});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: mainColor,
              offset: Offset(0, 2), //(x,y)
              blurRadius: 2,
            ),
          ]
      ),
      height: 160,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            "${this.phrase}",
            textAlign: TextAlign.center,
            style: TextStyle(
              color: greyColor,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          TextButton.icon(
            // ignore: unnecessary_statements
            onPressed: () {},
            label: Text(
              '${this.buttonText}',
              style: TextStyle(fontSize: 25,color : mainColor),
            ),
            icon: Icon(containerIcon , color: mainColor,size: 35,),
          )
        ],
      ),
    );
  }
}
